<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<?php include "includes/header.php"; ?>
			<!---start-content----->
			<div class="content">
				<!---start-services----->
				<div class="services">
					<div class="wrap">
						<div class="service-content">
							<h3>activities</h3>
							<ul>
								<!---<li><span>1.</span></li>----->
								<li><p><a href="welfare.php">Social services  and Welfare committe</a>ICA has been actively involved in various welfare and volantary activities for Malayalees in Singapore. ICA is increasingly playing its part in the nation building.</p><a href="welfare.php">[Read more]</a></li>
								<div class="clear"> </div>
							</ul>
							<ul>
								<!---<li><span>1.</span></li>----->
								<li><p><a href="sports.php">Youth wing and sports committee </a>ICA sports committe conducts events like Badminton tournament,Chess and Caroms tournament,soccer tournament and ICA Vishu Events.</p><a href="sports.php">[Read more]</a></li>
								
							</ul>
							<ul>
								<!---<li><span>1.</span></li>----->
								<li><p><a href="arts.php">Cultural Activities and Arts committee</a>ICA arts committe had wonderful years since 2006. In the interest of various communities we didi our best in terms of organisingsome remarkable cultural evevnts and plan to do many more in coming years</p><a href="arts.php">[Read more]</a></li>
								<div class="clear"> </div>
							</ul>
							<ul>
								<!---<li><span>1.</span></li>----->
								<li><p><a href="interaction.php">family gathering and Interaction committee</a>InteracInteraction committee is increasingly playing its part in to promote the interest and developemnts of the Inddian communitty in Singaporethrough engagingthem in Intelectual,Cultural Social Sporting and recreational activities</p><a href="interaction.php">[Read more]</a></li>
								<div class="clear"> </div>
							</ul>
							
                            
                           <!-- <ul>
								<li><span>5.</span></li>
								<li><p><a href="#">RETAIL INDUSTRY</a>Praesent vestibulum molestie lacus. Aenean nonummy hendrerit mauris. Phasellus porta. Fusce suscipit varius mi. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nulla dui.</p></li>
								<div class="clear"> </div>
							</ul>
							<ul>
								<li><span>6.</span></li>
								<li><p><a href="#">RETAIL INDUSTRY</a>Praesent vestibulum molestie lacus. Aenean nonummy hendrerit mauris. Phasellus porta. Fusce suscipit varius mi. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nulla dui.</p></li>
								<div class="clear"> </div>
							</ul>-->
                            
                            
						</div>
						<!--<div class="services-sidebar">
							<h3>WE PROVIDE</h3>
							 <ul>
							  	<li><a href="#">Lorem ipsum dolor sit amet</a></li>
							  	<li><a href="#">Conse ctetur adipisicing</a></li>
							  	<li><a href="#">Elit sed do eiusmod tempor</a></li>
							  	<li><a href="#">Incididunt ut labore</a></li>
							  	<li><a href="#">Et dolore magna aliqua</a></li>
							  	<li><a href="#">Ut enim ad minim veniam</a></li>
					 		 </ul>
					 		 <h3>ARCHIVES</h3>
					 		 <ul>
					 		 	<li><a href="#">JAN, 2013</a></li>
					 		 	<li><a href="#">FEB, 2013</a></li>
					 		 	<li><a href="#">MAR, 2013</a></li>
					 		 	<li><a href="#">APRIL, 2013</a></li>
					 		 </ul>
						</div>-->
						<div class="clear"> </div>
					</div>
				<!---End-services----->
			<!---End-content----->
		</div>
		<div class="clear"></div>
		
                
                
              <!--  <div class="ourteam">
				<div class="wrap">
			<h3>Our<span> team</span></h3>
									<div class="section group">
										<div class="grid_1_of_4 images_1_of_4">
											 <img src="images/team.jpg">
											 <h4>Lorem Ipsum is simply </h4>
											 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.<a href="#">[...]</a></p>
										</div>
										<div class="grid_1_of_4 images_1_of_4">
											 <img src="images/team.jpg">
											 <h4>Lorem Ipsum is simply </h4>
											 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.<a href="#">[...]</a></p>
										</div>
										<div class="grid_1_of_4 images_1_of_4">
											 <img src="images/team.jpg">
											 <h4>Lorem Ipsum is simply </h4>
											 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.<a href="#">[...]</a></p>
										</div>
										<div class="grid_1_of_4 images_1_of_4">
											 <img src="images/team.jpg">
											 <h4>Lorem Ipsum is simply </h4>
											 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.<a href="#">[...]</a></p>
										</div>
									</div>
								</div>						
			
			</div>-->
                
                
                
                
		</div>
	</div>
	<div class="clear"></div>
	<!---End-content----->
		</div>
		</div>
		<!---start-footer----->
		
<?php include "includes/footer.php"; ?>


		<!---End-wrap---->
		
	</body>
</html>


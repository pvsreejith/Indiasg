<?php
$to = "enquiry@indiasg.com";
$subject = "My subject";
$txt = "Hello world!";
$headers = "From: pvs1980@gmail.com";

mail($to,$subject,$txt,$headers);
?>
<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<?php include "includes/header.php"; ?>










			</div>
			<!---start-content----->
			<div class="content">
				<!---start-Contact----->
				<div class="contact">
					<div class="wrap">
					<!---<h1><span></span></h1>----->
				<div class="section group">				
				<div class="col span_1_of_3">
					<div class="contact_info">
			    	 	<h3>Find Us Here</h3>
			    	 		<div class="map">
					   			<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d255281.11564629094!2d103.70693399258111!3d1.3150700770020218!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31da11238a8b9375%3A0x887869cf52abf5c4!2sSingapore!5e0!3m2!1sen!2sin!4v1489765250967" width="400" height="300" frameborder="0" style="border:0" allowfullscreen></iframe><br><small><a href="https://www.google.com/maps/place/Singapore/@1.3150701,103.706934,11z/data=!3m1!4b1!4m5!3m4!1s0x31da11238a8b9375:0x887869cf52abf5c4!8m2!3d1.352083!4d103.819836?hl=en">View Larger Map</a></small>
					   		</div>
      				</div>
      			<div class="company_address">
				     	<h3>Contact us :</h3>						    	
				   		<p>If you would like further information email us at enquiry@indiasg.com or call us +65 98565542 </p>
				   		
				   		

				   </div>
				</div>
                    
				<!--<div class="col span_2_of_3">
				  <div class="contact-form">
				  	<h3>Contact Us</h3>
					    <form action="contact.php" method="post">
					    	<div>
						    	<span><label>NAME</label></span>
						    	<span><input name="userName" type="text" class="textbox"></span>
						    </div>
						    <div>
						    	<span><label>E-MAIL</label></span>
						    	<span><input name="userEmail" type="text" class="textbox"></span>
						    </div>
						    <div>
						     	<span><label>MOBILE</label></span>
						    	<span><input name="userPhone" type="text" class="textbox"></span>
						    </div>
						    <div>
						    	<span><label>SUBJECT</label></span>
						    	<span><textarea name="userMsg"> </textarea></span>
						    </div>
						   <div>
						   		<span><input type="submit" value="submit"></span>
						  </div>
					    </form>
                      
                      
                      
                      

				    </div>
  				</div>	-->
                    
                    
			  </div>
			</div>
			<!---End-contact----->
		</div>
			<!---End-content----->
		</div>
		<div class="clear"></div>
		</div>
	</div>
	<div class="clear"></div>
		<!---End-content----->
		</div>
		</div>
		<!---start-footer----->
		
<?php include "includes/footer.php"; ?>


		<!---End-wrap---->
		
	</body>
</html>


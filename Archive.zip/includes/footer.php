<div class="footer">
			<div class="wrap">
				<div class="footer-left">
					<a href="index.php">Indian Cultural Association</a>
				</div>
				<div class="footer-right">
					<p> | Design by <a href="https://www.linkedin.com/in/sreejith-palliveetil-96944233/" target="_blank">Sreejith</a></p>
					<script type="text/javascript">
							$(document).ready(function() {
								/*
								var defaults = {
						  			containerID: 'toTop', // fading element id
									containerHoverID: 'toTopHover', // fading element hover id
									scrollSpeed: 1200,
									easingType: 'linear' 
						 		};
								*/
								
								$().UItoTop({ easingType: 'easeOutQuart' });
								
							});
						</script>
   					 <a href="#" id="toTop" style="display: block;"><span id="toTopHover" style="opacity: 1;"></span></a>
				</div>
                
				<div class="clear"> </div>
			</div>
		</div>
		<!---End-footer----->
<!DOCTYPE HTML>
<?php include "includes/header.php"; ?>
			<!---start-content----->
			<div class="content">
				<!---start-services----->
				<div class="services">
					<div class="wrap">
						<div class="service-content">
							
							<ul>
								<!---<li><span>1.</span></li>----->
								<li><h3>Youth wing and sports committee</h3><p>ICA sports committe conducts events like Badminton tournament,Chess and Caroms tournament,soccer tournament and ICA Vishu Events.</p></li>
								<div class="clear"> </div>
							</ul>
                            <ul>
								
								<li><new>1.Badminton Tournament</new> <p>ICA sports committe conducts events like Badminton tournaments in past years,which is one of the major events for us</p></li>
								<div class="clear"> </div>
							</ul>
                            
                           
                            <ul>
								
								<li><new>2.Chess and Caroms tournament</new> <p>This event was very well received by the participant</p></li>
								<div class="clear"> </div>
							</ul>
                             <ul>
								
								<li><new>3.Soccer tournament</new> <p>ICA sports committee also conductedthe soccer tournament (Fustal) for malayalee community during every year July-August</p></li>
								<div class="clear"> </div>
							</ul>
                            
                            
                            <ul>
								
								<li><new>4.ICA Vishu</new> <p>For the past years ICA celeberationg Vishu at Sembawang CC in April. The highlight of this event was sports events for children, adult and veterans along with cultural program. And as per our tradition, Vishu Sadhya(Vishu Feast) was served to more than 700 persons.As usual VADAM VALI(Tug-of-war) for adults-men/ladies and children were some of the notable events of that day.</p></li>
								<div class="clear"> </div>
							</ul>
							
							
                            
                          
                            
                            
						</div>
						<!--<div class="services-sidebar">
							<h3>WE PROVIDE</h3>
							 <ul>
							  	<li><a href="#">Lorem ipsum dolor sit amet</a></li>
							  	<li><a href="#">Conse ctetur adipisicing</a></li>
							  	<li><a href="#">Elit sed do eiusmod tempor</a></li>
							  	<li><a href="#">Incididunt ut labore</a></li>
							  	<li><a href="#">Et dolore magna aliqua</a></li>
							  	<li><a href="#">Ut enim ad minim veniam</a></li>
					 		 </ul>
					 		 <h3>ARCHIVES</h3>
					 		 <ul>
					 		 	<li><a href="#">JAN, 2013</a></li>
					 		 	<li><a href="#">FEB, 2013</a></li>
					 		 	<li><a href="#">MAR, 2013</a></li>
					 		 	<li><a href="#">APRIL, 2013</a></li>
					 		 </ul>
						</div>-->
						<div class="clear"> </div>
					</div>
				<!---End-services----->
			<!---End-content----->
		</div>
		<div class="clear"></div>
		<!---<div class="ourteam">
				<div class="wrap">
			<h3>Our<span> team</span></h3>
									<div class="section group">
										<div class="grid_1_of_4 images_1_of_4">
											 <img src="images/team.jpg">
											 <h4>Lorem Ipsum is simply </h4>
											 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.<a href="#">[...]</a></p>
										</div>
										<div class="grid_1_of_4 images_1_of_4">
											 <img src="images/team.jpg">
											 <h4>Lorem Ipsum is simply </h4>
											 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.<a href="#">[...]</a></p>
										</div>
										<div class="grid_1_of_4 images_1_of_4">
											 <img src="images/team.jpg">
											 <h4>Lorem Ipsum is simply </h4>
											 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.<a href="#">[...]</a></p>
										</div>
										<div class="grid_1_of_4 images_1_of_4">
											 <img src="images/team.jpg">
											 <h4>Lorem Ipsum is simply </h4>
											 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.<a href="#">[...]</a></p>
										</div>
									</div>
								</div>						
			end-about
			</div>----->
		</div>
	</div>
	<div class="clear"></div>
		<!---start-footer----->
		<div class="footer">
			<div class="wrap">
				<div class="footer-left">
					<a href="index.php">INDIAN CULTURAL ASSOCIATION</a>
				</div>
				<div class="footer-right">
					<p> | Design by <a href="https://www.linkedin.com/in/neeraja-sreejith-39a29b141" target="_blank">neeraja</a></p>
					<script type="text/javascript">
							$(document).ready(function() {
								/*
								var defaults = {
						  			containerID: 'toTop', // fading element id
									containerHoverID: 'toTopHover', // fading element hover id
									scrollSpeed: 1200,
									easingType: 'linear' 
						 		};
								*/
								
								$().UItoTop({ easingType: 'easeOutQuart' });
								
							});
						</script>
   					 <a href="#" id="toTop" style="display: block;"><span id="toTopHover" style="opacity: 1;"></span></a>
				</div>
				<div class="clear"> </div>
			</div>
		</div>
		<!---End-footer----->
		<!---End-wrap---->
		
	</body>
</html>


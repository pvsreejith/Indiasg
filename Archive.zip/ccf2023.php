<!DOCTYPE HTML>
<?php include "includes/header.php"; ?>
			<div style="text-align:center;" > 
			
		
			    <img src="images/CCF2023.png" align="center"  width="40%" >
			    
			
					   			
					   			
					   			
					   		<!--- <p><a   style='font-size:1.45em' > <font color="green"> &nbsp &nbsp;&nbsp;&nbsp;&nbsp REGISTRATION WILL BE BETWEEN 20TH DECEMBER 2017 AND 15TH JANUARY 2018 <span style="font-weight:bold"> </a> </p> --->
      				

                     <!---    <p><a href='https://docs.google.com/forms/d/e/1FAIpQLSeD89nb3XyW4ap14gk5JG8S7atr-2CuvryBB9BhvhjdNpAv4A/viewform' target="_blank" style='font-size:1.8em' > <font color="green"> &nbsp &nbsp;&nbsp;&nbsp FOR REGISTRATION CLICK HERE <span style="font-weight:bold"> </a></p>   ---> 

                              <!---     <p><a style='font-size:1.8em' > <font color="green"> &nbsp &nbsp;&nbsp;&nbsp REGISTRATION IS CLOSED <span style="font-weight:bold"> </a></p> ---> 

<p>&nbsp</p>  

                       <!---   <p><a style='font-size:1.8em' > <font color="green"> &nbsp &nbsp;&nbsp;&nbsp REGISTRATION IS CLOSED <span style="font-weight:bold"> </a></p>  ---> 



                      <!---     <p><a href='Rules&Regulations.php' style='font-size:1.8em' > <font color="red"> &nbsp &nbsp;&nbsp;&nbsp FOR RULES AND REGULATIONS  CLICK HERE <span style="font-weight:bold"> </a></p> ---> 

  <!---           ---> 




</div>
<p>&nbsp</p>

<p>&nbsp</p>

<p>&nbsp</p>

<p>&nbsp</p>

<p>&nbsp</p>

<p>&nbsp</p>
</div>


      			<!--<div class="company_address">
				     	<h3>Company Information :</h3>
						    	<p>500 Lorem Ipsum Dolor Sit,</p>
						   		<p>22-56-2-9 Sit Amet, Lorem,</p>
						   		<p>USA</p>
				   		<p>Phone:(00) 222 666 444</p>
				   		<p>Fax: (000) 000 00 00 0</p>
				 	 	<p>Email: <a href="mailto:info@gmail.com">info[at]mycompany.com</a></p>
				   		<p>Follow on: <a href="#">Facebook</a>, <a href="#">Twitter</a></p>

				   </div>-->
				</div>	
                    
				<!---<div class="col span_2_of_3">
				  <div class="contact-form">
				  	<h3>register now </h3>
					    <form>
					    	<div>
						    	<span><label>NAME</label></span>
						    	<span><input name="userName" type="text" class="textbox"></span>
						    </div>
						    <div>
						    	<span><label>E-MAIL</label></span>
						    	<span><input name="userEmail" type="text" class="textbox"></span>
						    </div>
						    <div>
						     	<span><label>MOBILE</label></span>
						    	<span><input name="userPhone" type="text" class="textbox"></span>
						    </div>
						    <div>
						    	<span><label>SUBJECT</label></span>
						    	<span><textarea name="userMsg"> </textarea></span>
						    </div>
						   <div>
						   		<span><input type="submit" value="Submit"></span>
						  </div>
					    </form>

				    </div>
  				</div>	----->
                    
                    
			  </div>
			</div>
			<!---End-contact----->
		</div>
			<!---End-content----->
		</div>
		<div class="clear"></div>

			
		</div>
	</div>
	<div class="clear"></div>
		<!---start-footer
		<div class="footer">
			<div class="wrap">
				<div class="footer-left">
					<a href="index.php">INDIAN CULTURAL ASSOCIATION</a>
				</div>
				<div class="footer-right">
					<p> | Design by <a href="https://www.linkedin.com/in/neeraja-sreejith-39a29b141" target="_blank">Neeraja</a></p>
					<script type="text/javascript">
							$(document).ready(function() {
								/*
								var defaults = {
						  			containerID: 'toTop', // fading element id
									containerHoverID: 'toTopHover', // fading element hover id
									scrollSpeed: 1200,
									easingType: 'linear' 
						 		};
								*/
								
								$().UItoTop({ easingType: 'easeOutQuart' });
								
							});
						</script>
   					 <a href="#" id="toTop" style="display: block;"><span id="toTopHover" style="opacity: 1;"></span></a>
				</div>
				<div class="clear"> </div>
			</div>
		</div>
		End-footer----->
		
		<?php include "includes/footer.php"; ?>
		<!---End-wrap---->
		
	</body>
</html>


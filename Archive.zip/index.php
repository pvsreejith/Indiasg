  
  <?php include "includes/header.php"; ?>
			<!---start-image-slider---->
			
		


			
			 <div class="slider">
			 	<div class="wrap">
			<div class="fluid_container">
		        <div class="camera_wrap camera_azure_skin" id="camera_wrap_1">
		            
		             <div data-thumb="images/10914998_827097927331553_8066844537931451249_o.jpg" data-src="images/10914998_827097927331553_8066844537931451249_o.jpg">
		                 
		             </div>
		            <div data-thumb="images/10914998_827097927331553_8066844537931451248_o.jpg" data-src="images/10914998_827097927331553_8066844537931451248_o.jpg">
		               
		            </div>
		           <div data-thumb="images/11893969_10153011962337761_3440571697895934458_o.jpg" data-src="images/11893969_10153011962337761_3440571697895934458_o.jpg">
		             

                            </div>
		             <div data-thumb="images/11892478_10153011961012761_3036053109804482873_o.jpg" data-src="images/11892478_10153011961012761_3036053109804482873_o.jpg">
		               
		            </div>
		            <div data-thumb="images/Singa.jpg" data-src="images/Singa.jpg">
		               
		            </div>
		        </div><!-- #camera_wrap_1 -->
		        <script type='text/javascript' src='js/jquery.min.js'></script>
			    <script type='text/javascript' src='js/jquery.mobile.customized.min.js'></script>
			    <script type="text/javascript" src="js/jquery.easing.min.js"></script>
			    <script type='text/javascript' src='js/camera.min.js'></script> 
				</div>
                    
                    
                    
                    
                    
                    
                    
                   				<!---start-bottom-grids----->
				<div class="bottom-grids">
					<div class="wrap">
					<div class="mid-grids-head">
						<div class="mid-grids-head-left">
								<!---<h4><span>Our</span> INDIAN CULTURAL ASSOCIATION</h4>----->
                            <h4><marquee behavior="alternate">INDIAN CULTURAL ASSOCIATION</marquee></h4>
						</div>
						<div class="=&quot;clear&quot;"> </div>
					</div>
					<div class="bottom-grid-left">
						<div class="bottom-grid-left-grid">
							<div class="bottom-grid-left-grid-pic">
								<img src="images/inaugration1.png" alt="">
							</div>
							<div class="bottom-grid-left-grid-info">
								<!--<h3>Lorem ipsum dolor sit amet, consectetur adipisicing elit,</h3>
								<ul class="in-list">
									<li><a href="#">May 3rd, 2013 |</a></li>
									<li><a href="#">1 Comment</a></li>
								</ul>-->
                                <h3><p>Indian Cultural Association Singapore,a truely volunteer organisation was taken birth with the primary aim of Socio-cultural integration of Indian diaspora in singapore. It was conceived a decade ago, as a result of unconditional and selfless initiative by a group of working professionals. since then ICAS has been involving in various activities with full dedication.</p></h3>
							</div>
							<!--<div class="clear"> </div>-->
						</div>
                        
                        
						<div class="bottom-grid-left-grid">
							<div class="bottom-grid-left-grid-pic">
								<img src="images/inaugration2.png" alt="">
							</div>
							<div class="bottom-grid-left-grid-info">
								<!--<h3>Lorem ipsum dolor sit amet, consectetur adipisicing elit,</h3>
								<ul class="in-list">
									<li><a href="#">May 3rd, 2013 |</a></li>
									<li><a href="#">1 Comment</a></li>
								</ul>
								<p>consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.<a href="#">[...]</a></p>-->
							</div>
							<div class="clear"> </div>
						</div>
                        
                        
                        
                        
                        
						<!--<a class="all" href="#">View all</a>-->
					</div>
					<!--<div class="bottom-grid-right">
						<iframe src="//player.vimeo.com/video/71543851" width="100%" height="330" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen> </iframe> 
						<a href="#">View all videos</a>
					</div>-->
                        
                     <!--   <div class="bottom-grid-right">
						<iframe  src="video/20140906_185338.mp4" width="100%" height="250" frameborder="0"> </iframe> 
						
					</div>-->
                      <div class="bottom-grid-right">  
                                    
						 <video width="85%" height="250" controls autoplay="autoplay"  loop="loop"  muted playsinline>
                                     <source src="video/20140906_185338.mp4" type="video/mp4">
                          
				
                      </div>                     
                        
                    
					<div class="clear"> </div>
				</div>
			</div>
                    <div class="mid-grids-head-left-new">
							<!---<h4><span>Our</span> Gallery</h4
                            <h3><span>Upcoming events</span></h3>>-->
                            
						</div>
                    
				<!---End-bottom-grids-----> 
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
       					<!---<div class="clear"> </div>
       			<div class="shadow">
       				<img src="images/shadow.png" alt="" />
       			</div>---->
                    
                    
                   <!---  <div class="mid-grids-head-left-new-mar"> 
               <marquee style="color:red" scrollamount="15" onmouseover="this.stop();" onmouseout="this.start();"><h3><span>Upcoming Event: ICA SPORTS DAY </span></h3></marquee></a>
                     
                   </div>

                    
			End-image-slider 
			</div>
              </div> ---->

 
                      <!---   <div class="mid-grids-head-left-new-mar"> 
                      <a href="ccf2021.php"> 
               <marquee style="color:red" scrollamount="15" onmouseover="this.stop();" onmouseout="this.start();"><h3><span>Upcoming Event: CHILDREN CULTURAL FEST-2021 </span></h3></marquee></a>
                     
                   </div>  ----> 



                    
			
			</div> 
              </div>  





              <!---  ---->  <div class="mid-grids-head-left-new-mar">
              <a href="ccf2023.php">  <marquee style="color:red" scrollamount="10" onmouseover="this.stop();" onmouseout="this.start();"><h3><span>Upcoming Event: CHILDREN CULTURAL FEST-2023,CLICK HERE FOR DETAILS. </span></h3></marquee></a>
                     
                   </div>
                   
                   
              <!---  <div class="mid-grids-head-left-new-mar">
              <a href="ccf2020.php">  <marquee style="color:red" scrollamount="15" onmouseover="this.stop();" onmouseout="this.start();"><h3><span>CHILDREN CULTURAL FEST-2020 :- In light of the recent developments on the Coronavirus in Singapore, the Organising Committee regrets to inform that the event will be postponed till further notice.  We seek your kind understanding. </span></h3></marquee></a>
                     
                   </div>   ---->



              <!---  <div class="mid-grids-head-left-new-mar">
              <a href="VISHU2019.php">  <marquee style="color:red" scrollamount="15" onmouseover="this.stop();" onmouseout="this.start();"><h3><span>Upcoming Event: VISHU-2019,CLICK HERE FOR DETAILS. </span></h3></marquee></a>
                     
                   </div>  ---->



                    
			
			</div>
              </div>
 



			<!---start-content----->
			<div class="content">
                
				<!---start-top-grids----->
				
				<!---End-top-grids----->
				<!---start-mid-grids----->

				<!---<div class="mid-grids">   <h3><span>ICA-10 wishes</span></h3>
					<div class="wrap">----->

                         <div class="mid-grids">
                        <p style="text-align: center;"><bold style="font-size: 200%;">ICA-10 WISHES</bold>
                         </p>

					<!--<div class="mid-grids-head">
						<div class="mid-grids-head-left-new">							
                            <h3><span>Recent events</span></h3>                            
						</div>
						<div class=="clear"> </div>
					</div>
					<div class="mid-grid1 last-grid">
						<div class="mid-grid effect">
							<img src="images/g1.jpg" />
					        <div class="mask">
								<a href="#" class="info">Read More</a>
							</div>
						</div>
					</div>
					<div class="mid-grid1 last-grid">
						<div class="mid-grid effect">
							<img src="images/g2.jpg" />
					        <div class="mask">
								<a href="#" class="info">Read More</a>
							</div>
						</div>
					</div>
                        
                    <div class="mid-grid1 last-grid1">
						<div class="mid-grid effect">
							<img src="images/g3.jpg" />
					        <div class="mask">
								<a href="#" class="info">Read More</a>
							</div>
						</div>
					</div>-->
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
					<div class="mid-grid1 last-grid">
						<div class="mid-grid">
							<img src="images/message2.png" />
					        <div class="mask">
								<!--<a href="#" class="info">Read More</a>-->
							</div>
						</div>
					</div>
					<div class="mid-grid1 last-grid">
						<div class="mid-grid">
							<img src="images/message1.png" />
					        <div class="mask">
								<!--<a href="#" class="info">Read More</a>-->
							</div>
						</div>
					</div>
					<div class="mid-grid1 last-grid1">
						<div class="mid-grid">
							<img src="images/message3.png" />
					        <div class="mask">
								<!--<a href="#" class="info">Read More</a>-->
							</div>
						</div>
					</div>
					<div class="clear"> </div>
				</div>
				</div>
				<!---End-mid-grids----->

			</div>
<!---<div class="top-grids">
					<div class="wrap">
						<div class="top-grid top-grid1">
							<a class="icon01" href="#"> </a>
							<h2><span>Our</span>TRAINING</h2>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam</p>
						</div>
						<div class="top-grid top-grid2">
							<a class="icon02" href="#"> </a>
							<h2><span>Our</span>Medicals</h2>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam</p>
						</div>
						<div class="top-grid last-grid">
							<a class="icon03" href="#"> </a>
							<h2><span>Our</span>Specials</h2>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam</p>
						</div>
						<div class="clear"> </div>
					</div>
				</div>----->












			<!---End-content----->
		</div>
		</div>
		<!---start-footer----->
		
<?php include "includes/footer.php"; ?>


		<!---End-wrap---->
		
	</body>
</html>


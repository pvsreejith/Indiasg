<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<?php include "includes/header.php"; ?>
			<!---start-content----->
			<div class="content">
				<!---start-services----->
				<div class="services">
					<div class="wrap">
						<div class="service-content">
							
							<ul>

								<!---<li><span>1.</span></li>----->
			
                



<html>

<head>
<meta http-equiv=Content-Type content="text/html; charset=windows-1252">
<meta name=Generator content="Microsoft Word 15 (filtered)">
<style>
<!--
 /* Font Definitions */
 @font-face
	{font-family:Wingdings;
	panose-1:5 0 0 0 0 0 0 0 0 0;}
@font-face
	{font-family:"Cambria Math";
	panose-1:2 4 5 3 5 4 6 3 2 4;}
@font-face
	{font-family:Calibri;
	panose-1:2 15 5 2 2 2 4 3 2 4;}
@font-face
	{font-family:Calibri-Bold;
	panose-1:0 0 0 0 0 0 0 0 0 0;}
@font-face
	{font-family:ArialNarrow;
	panose-1:0 0 0 0 0 0 0 0 0 0;}
 /* Style Definitions */
 p.MsoNormal, li.MsoNormal, div.MsoNormal
	{margin-top:0cm;
	margin-right:0cm;
	margin-bottom:8.0pt;
	margin-left:0cm;
	line-height:106%;
	font-size:11.0pt;
	font-family:"Calibri",sans-serif;}
a:link, span.MsoHyperlink
	{color:#0563C1;
	text-decoration:underline;}
p.MsoListParagraph, li.MsoListParagraph, div.MsoListParagraph
	{margin-top:0cm;
	margin-right:0cm;
	margin-bottom:8.0pt;
	margin-left:36.0pt;
	line-height:106%;
	font-size:11.0pt;
	font-family:"Calibri",sans-serif;}
p.MsoListParagraphCxSpFirst, li.MsoListParagraphCxSpFirst, div.MsoListParagraphCxSpFirst
	{margin-top:0cm;
	margin-right:0cm;
	margin-bottom:0cm;
	margin-left:36.0pt;
	line-height:106%;
	font-size:11.0pt;
	font-family:"Calibri",sans-serif;}
p.MsoListParagraphCxSpMiddle, li.MsoListParagraphCxSpMiddle, div.MsoListParagraphCxSpMiddle
	{margin-top:0cm;
	margin-right:0cm;
	margin-bottom:0cm;
	margin-left:36.0pt;
	line-height:106%;
	font-size:11.0pt;
	font-family:"Calibri",sans-serif;}
p.MsoListParagraphCxSpLast, li.MsoListParagraphCxSpLast, div.MsoListParagraphCxSpLast
	{margin-top:0cm;
	margin-right:0cm;
	margin-bottom:8.0pt;
	margin-left:36.0pt;
	line-height:106%;
	font-size:11.0pt;
	font-family:"Calibri",sans-serif;}
.MsoChpDefault
	{font-size:10.0pt;
	font-family:"Calibri",sans-serif;}
@page WordSection1
	{size:595.3pt 841.9pt;
	margin:72.0pt 34.25pt 72.0pt 72.0pt;
	border:double windowtext 4.5pt;
	padding:24.0pt 24.0pt 24.0pt 24.0pt;}
div.WordSection1
	{page:WordSection1;}
 /* List Definitions */
 ol
	{margin-bottom:0cm;}
ul
	{margin-bottom:0cm;}
-->
</style>

</head>

<body lang=EN-SG link="#0563C1" vlink="#954F72" style='word-wrap:break-word'>

<div class=WordSection1>

<p class=MsoNormal align=center style='margin-bottom:0cm;text-align:center;
line-height:normal;text-autospace:none'><b><u><span style='font-size:17.5pt;
font-family:Calibri-Bold;color:red'>Rules and Regulations for ICA Children
Cultural Fest 2021</span></u></b></p>

<p class=MsoNormal style='margin-bottom:0cm;line-height:normal;text-autospace:
none'><span style='font-size:17.5pt;font-family:Calibri-Bold;color:red'>&nbsp;</span></p>

<p class=MsoNormal style='margin-bottom:0cm;line-height:normal;text-autospace:
none'><b><span style='font-size:14.0pt;font-family:Calibri-Bold;color:red'>General
Rules</span></b></p>

<p class=MsoNormal style='margin-bottom:0cm;line-height:normal;text-autospace:
none'><b><span style='font-size:14.0pt;font-family:Calibri-Bold;color:red'>&nbsp;</span></b></p>

<p class=MsoNormal style='margin-top:0cm;margin-right:7.1pt;margin-bottom:0cm;
margin-left:0cm;text-align:justify;line-height:normal;text-autospace:none'><b><span
style='font-size:14.0pt;color:black'>Indian Cultural Association Children
Cultural Fest (CCF) 2021</span></b><span style='font-size:14.0pt;color:black'> will
be conducted during the month of April ’21. </span></p>

<p class=MsoNormal style='margin-top:0cm;margin-right:7.1pt;margin-bottom:0cm;
margin-left:0cm;text-align:justify;line-height:normal;text-autospace:none'><span
style='font-size:14.0pt;color:black'>&nbsp;</span></p>

<p class=MsoNormal style='margin-bottom:0cm;text-align:justify;text-indent:
18.0pt;line-height:normal;text-autospace:none'><span style='font-size:14.0pt;
color:black'>Due to the ongoing Pandemic, CCF 2021 will be conducted a VIRTUAL
EVENT this time on Facebook, not as a Competition.</span></p>

<p class=MsoNormal style='margin-bottom:0cm;text-align:justify;text-indent:
3.0pt;line-height:normal;text-autospace:none'><span style='font-size:12.0pt;
color:black'>&nbsp;</span></p>

<p class=MsoListParagraphCxSpFirst style='margin-bottom:0cm;text-align:justify;
text-indent:-18.0pt;line-height:normal;text-autospace:none'><span
style='font-size:12.0pt;font-family:"Courier New";color:black'>o<span
style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp; </span></span><span
style='font-size:12.0pt;color:black'>All the Participants will be awarded with
Participation Certificate.</span></p>

<p class=MsoListParagraphCxSpMiddle style='margin-bottom:0cm;text-align:justify;
text-indent:-18.0pt;line-height:normal;text-autospace:none'><span
style='font-size:12.0pt;font-family:"Courier New";color:black'>o<span
style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp; </span></span><span
style='font-size:12.0pt;color:black'>Category wise streaming will be performed
weekly basis through INDIAN CULTURAL ASSOCIATION FB Page.   </span></p>

<p class=MsoListParagraphCxSpMiddle style='margin-bottom:0cm;text-align:justify;
text-indent:-18.0pt;line-height:normal;text-autospace:none'><span
style='font-size:12.0pt;font-family:"Courier New";color:black'>o<span
style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp; </span></span><span
style='font-size:12.0pt;color:black'>There is no separate competition for girls
and boys.</span></p>

<p class=MsoListParagraphCxSpMiddle style='margin-bottom:0cm;text-align:justify;
text-indent:-18.0pt;line-height:normal;text-autospace:none'><span
style='font-size:12.0pt;font-family:"Courier New";color:black'>o<span
style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp; </span></span><span
style='font-size:12.0pt;color:black'>A Participant can attend in maximum two Single
and two Group items</span></p>

<p class=MsoListParagraphCxSpMiddle style='margin-bottom:0cm;text-align:justify;
text-indent:-18.0pt;line-height:normal;text-autospace:none'><span
style='font-size:12.0pt;font-family:"Courier New";color:black'>o<span
style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp; </span></span><span
style='font-size:12.0pt;color:black'>Programs should be Practised / Recorded
under COVID guidelines.</span></p>

<p class=MsoListParagraphCxSpMiddle style='margin-bottom:0cm;text-align:justify;
text-indent:-18.0pt;line-height:normal;text-autospace:none'><span
style='font-size:12.0pt;font-family:"Courier New";color:black'>o<span
style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp; </span></span><span
style='font-size:12.0pt;color:black'>Maximum number of participants for group
events should be “8” as per COVID Protocol.</span></p>

<p class=MsoListParagraphCxSpMiddle style='margin-bottom:0cm;text-align:justify;
text-indent:-18.0pt;line-height:normal;text-autospace:none'><span
style='font-size:12.0pt;font-family:"Courier New";color:black'>o<span
style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp; </span></span><span
style='font-size:12.0pt;color:black'>No Registration Fee will be collected in
any part of the program.</span></p>

<p class=MsoListParagraphCxSpMiddle style='margin-bottom:0cm;text-align:justify;
text-indent:-18.0pt;line-height:normal;text-autospace:none'><span
style='font-size:12.0pt;font-family:"Courier New";color:black'>o<span
style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp; </span></span><span
style='font-size:12.0pt;color:black'>Selection will be explicitly based on the high
quality of Sound &amp; Video received. </span></p>

<p class=MsoListParagraphCxSpMiddle style='margin-bottom:0cm;text-align:justify;
text-indent:-18.0pt;line-height:normal;text-autospace:none'><span
style='font-size:12.0pt;font-family:"Courier New";color:black'>o<span
style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp; </span></span><span
style='font-size:12.0pt;color:black'>Maximum of 15 entries per Item.</span></p>

<p class=MsoListParagraphCxSpLast style='margin-bottom:0cm;text-align:justify;
text-indent:-18.0pt;line-height:normal;text-autospace:none'><span
style='font-size:14.0pt;font-family:"Courier New";color:black'>o<span
style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp; </span></span><span
style='font-size:12.0pt;color:black'>Entries to be Submitted before 22<sup>nd</sup>
Mar 2021 to </span><a href="mailto:icachildrenfest2021@gmail.com"><span
style='font-size:14.0pt'>icachildrenfest2021@gmail.com</span></a></p>

<p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
margin-left:7.1pt;text-align:justify;text-indent:-7.1pt;line-height:normal;
text-autospace:none'><span style='font-size:14.0pt;color:black'>&nbsp;</span></p>

<p class=MsoNormal style='margin-bottom:0cm;text-align:justify;line-height:
normal;text-autospace:none'><b><span style='font-size:14.0pt;font-family:Calibri-Bold;
color:red'>Age Category          <br>
<br>
</span></b></p>

<p class=MsoNormal style='margin-bottom:0cm;text-align:justify;line-height:
normal;text-autospace:none'><span style='font-size:14.0pt;color:black'>Age calculation
based on 15<sup>th</sup> March 2021.</span></p>

<p class=MsoNormal style='margin-bottom:0cm;text-align:justify;line-height:
normal;text-autospace:none'><span style='font-size:14.0pt;color:black'>&nbsp;</span></p>

<p class=MsoNormal style='margin-bottom:0cm;text-align:justify;line-height:
normal;text-autospace:none'><b><span style='font-size:14.0pt;font-family:Calibri-Bold;
color:red'>Individual Items     <br>
<br>
</span></b></p>

<p class=MsoNormal style='margin-bottom:0cm;text-align:justify;line-height:
normal;text-autospace:none'><b><span style='font-size:14.0pt;font-family:Calibri-Bold;
color:black'>1)  Below 08 years </span></b></p>

<p class=MsoNormal style='margin-bottom:0cm;text-align:justify;line-height:
normal;text-autospace:none'><b><span style='font-size:14.0pt;font-family:Calibri-Bold;
color:black'>2)  08 to 10 years   </span></b></p>

<p class=MsoNormal style='margin-bottom:0cm;text-align:justify;line-height:
normal;text-autospace:none'><b><span style='font-size:14.0pt;font-family:Calibri-Bold;
color:black'>3)  11 to 14 years   </span></b></p>

<p class=MsoNormal style='margin-bottom:0cm;text-align:justify;line-height:
normal;text-autospace:none'><b><span style='font-size:14.0pt;font-family:Calibri-Bold;
color:black'>&nbsp;</span></b></p>

<p class=MsoNormal style='margin-bottom:0cm;text-align:justify;line-height:
normal;text-autospace:none'><b><span style='font-size:14.0pt;font-family:Calibri-Bold;
color:red'>Group Items            <br>
<br>
</span></b></p>

<p class=MsoNormal style='margin-bottom:0cm;text-align:justify;line-height:
normal;text-autospace:none'><b><span style='font-size:14.0pt;font-family:Calibri-Bold;
color:black'>1)  08 Years &amp; Below </span></b></p>

<p class=MsoNormal style='margin-bottom:0cm;text-align:justify;line-height:
normal;text-autospace:none'><b><span style='font-size:14.0pt;font-family:Calibri-Bold;
color:black'>2)  12 Years &amp; below </span></b></p>

<p class=MsoNormal style='margin-bottom:0cm;text-align:justify;line-height:
normal;text-autospace:none'><b><span style='font-size:14.0pt;font-family:Calibri-Bold;
color:black'>3)  Below 15 Years</span></b></p>

<p class=MsoNormal style='margin-bottom:0cm;text-align:justify;line-height:
normal;text-autospace:none'><b><span style='font-size:14.0pt;font-family:Calibri-Bold;
color:black'> </span></b></p>

<p class=MsoNormal style='margin-bottom:0cm;line-height:normal;text-autospace:
none'><b><i><span style='font-size:14.0pt;color:red'>*****INDIAN CULTURAL
ASSOCIATION Organisers reserve the right to change any of these Rules and
Regulations at any time without notice*****</span></i></b></p>

<p class=MsoNormal align=center style='margin-bottom:0cm;text-align:center;
line-height:normal;text-autospace:none'><i><span style='font-size:14.0pt;
color:black'>&nbsp;</span></i></p>

<p class=MsoNormal style='margin-bottom:0cm;line-height:normal;text-autospace:
none'><b><span style='font-size:12.0pt;font-family:Calibri-Bold;color:red'>Show
&amp; Tell (Below 8 years)</span></b></p>

<p class=MsoListParagraphCxSpFirst style='margin-bottom:0cm;text-indent:-18.0pt;
line-height:normal;text-autospace:none'><span style='font-size:10.0pt;
font-family:Symbol'>Þ<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><span style='font-size:10.0pt;color:black'>Maximum allowed time is
3 min.</span></p>

<p class=MsoListParagraphCxSpMiddle style='margin-bottom:0cm;text-indent:-18.0pt;
line-height:normal;text-autospace:none'><span style='font-size:10.0pt;
font-family:Symbol'>Þ<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><span style='font-size:10.0pt;color:black'>Show &amp; Tell should
be only in English.</span></p>

<p class=MsoListParagraphCxSpLast style='margin-bottom:0cm;text-indent:-18.0pt;
line-height:normal;text-autospace:none'><span style='font-size:9.0pt;
font-family:Symbol'>Þ<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><span style='font-size:10.0pt;color:black'>Mentioning
Participant's name &amp; Reading is not allowed during Show &amp; Tell.</span><span
style='font-size:9.0pt;color:black'><br>
<br>
</span></p>

<p class=MsoNormal style='margin-bottom:0cm;line-height:normal;text-autospace:
none'><span style='font-size:10.0pt;color:black'>There is no topic for this
competition.</span></p>

<p class=MsoNormal style='margin-bottom:0cm;line-height:normal;text-autospace:
none'><span style='font-size:8.0pt;font-family:"ArialNarrow",sans-serif;
color:black'>&nbsp;</span></p>

<p class=MsoNormal style='margin-bottom:0cm;line-height:normal;text-autospace:
none'><b><span style='font-size:12.0pt;font-family:Calibri-Bold;color:red'>Speech
(8 to 10 years &amp; 11 to 14 years)</span></b></p>

<p class=MsoListParagraphCxSpFirst style='margin-bottom:0cm;text-indent:-18.0pt;
line-height:normal;text-autospace:none'><span style='font-size:10.0pt;
font-family:Symbol'>Þ<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><span style='font-size:10.0pt;color:black'>Maximum allowed time
is 4 min.</span></p>

<p class=MsoListParagraphCxSpMiddle style='margin-bottom:0cm;text-indent:-18.0pt;
line-height:normal;text-autospace:none'><span style='font-size:10.0pt;
font-family:Symbol'>Þ<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><span style='font-size:10.0pt;color:black'>Speech should be only
in English.</span></p>

<p class=MsoListParagraphCxSpLast style='margin-bottom:0cm;text-indent:-18.0pt;
line-height:normal;text-autospace:none'><span style='font-size:10.0pt;
font-family:Symbol'>Þ<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><span style='font-size:10.0pt;color:black'>Mentioning
Participant's name and Reading is not allowed during the speech.<br>
<br>
</span></p>

<p class=MsoNormal style='margin-bottom:0cm;line-height:normal;text-autospace:
none'><b><span style='font-size:10.0pt;color:black'>Speech Topic </span></b><span
style='font-size:10.0pt;color:black'><br>
<b>0</b></span><b><span style='font-size:10.0pt;font-family:Calibri-Bold;
color:black'>8 to 10 </span></b><b><span style='font-size:10.0pt;color:black'>years
</span></b><span style='font-size:10.0pt;color:black'>category - “</span><b><span
style='font-size:10.0pt;font-family:Calibri-Bold;color:#385623'>My Favourite
Sports</span></b><b><span style='font-size:10.0pt;font-family:Calibri-Bold;
color:black'>”</span></b></p>

<p class=MsoNormal style='margin-bottom:0cm;line-height:normal;text-autospace:
none'><b><span style='font-size:10.0pt;font-family:Calibri-Bold;color:black'>11
to 14 years </span></b><span style='font-size:10.0pt;color:black'>category - “</span><b><span
style='font-size:10.0pt;font-family:Calibri-Bold;color:#385623'>My Lockdown Days”</span></b></p>

<p class=MsoNormal style='margin-bottom:0cm;line-height:normal;text-autospace:
none'><span style='font-size:8.0pt;font-family:"ArialNarrow",sans-serif;
color:black'>&nbsp;</span></p>

<p class=MsoNormal style='margin-bottom:0cm;line-height:normal;text-autospace:
none'><b><span style='font-size:12.0pt;font-family:Calibri-Bold;color:red'>Fancy
dress (Below 8 years)</span></b></p>

<p class=MsoListParagraphCxSpFirst style='margin-bottom:0cm;text-indent:-18.0pt;
line-height:normal;text-autospace:none'><span style='font-size:10.0pt;
font-family:Symbol'>Þ<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><span style='font-size:10.0pt;color:black'>Maximum allowed time
is 1 min.</span></p>

<p class=MsoListParagraphCxSpMiddle style='margin-bottom:0cm;text-indent:-18.0pt;
line-height:normal;text-autospace:none'><span style='font-size:10.0pt;
font-family:Symbol'>Þ<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><span style='font-size:10.0pt;color:black'>Participants are
allowed to talk; Language should be English.</span></p>

<p class=MsoListParagraphCxSpMiddle style='margin-bottom:0cm;text-indent:-18.0pt;
line-height:normal;text-autospace:none'><span style='font-size:10.0pt;
font-family:Symbol'>Þ<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><span style='font-size:10.0pt;color:black'>Properties are
allowed.</span></p>

<p class=MsoListParagraphCxSpLast style='margin-bottom:0cm;text-indent:-18.0pt;
line-height:normal;text-autospace:none'><span style='font-size:10.0pt;
font-family:Symbol'>Þ<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><span style='font-size:10.0pt;color:black'>Make-up and Costume must
be arranged by participants.</span></p>

<p class=MsoNormal style='margin-bottom:0cm;line-height:normal;text-autospace:
none'><span style='font-size:8.0pt;font-family:"ArialNarrow",sans-serif;
color:black'>&nbsp;</span></p>

<p class=MsoNormal style='margin-bottom:0cm;line-height:normal;text-autospace:
none'><b><span style='font-size:12.0pt;font-family:Calibri-Bold;color:red'>Vocal
Solo Music (8 to 10 years, 11 to 14 years)</span></b></p>

<p class=MsoListParagraphCxSpFirst style='margin-bottom:0cm;text-indent:-18.0pt;
line-height:normal;text-autospace:none'><span style='font-size:10.0pt;
font-family:Symbol'>Þ<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><span style='font-size:10.0pt;color:black'>Maximum allowed time
is 4 min.</span></p>

<p class=MsoListParagraphCxSpMiddle style='margin-bottom:0cm;text-indent:-18.0pt;
line-height:normal;text-autospace:none'><span style='font-size:10.0pt;
font-family:Symbol'>Þ<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><span style='font-size:10.0pt;color:black'>Karaoke is allowed.</span></p>

<p class=MsoListParagraphCxSpMiddle style='margin-bottom:0cm;text-indent:-18.0pt;
line-height:normal;text-autospace:none'><span style='font-size:10.0pt;
font-family:Symbol'>Þ<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><span style='font-size:10.0pt;color:black'>Film songs or Semi
Classical songs can be used.</span></p>

<p class=MsoListParagraphCxSpLast style='margin-bottom:0cm;text-indent:-18.0pt;
line-height:normal;text-autospace:none'><span style='font-size:10.0pt;
font-family:Symbol'>Þ<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><span style='font-size:10.0pt;color:black'>Songs in any Indian
language can be performed.</span></p>

<p class=MsoNormal style='margin-bottom:0cm;line-height:normal;text-autospace:
none'><span style='font-size:8.0pt;font-family:"ArialNarrow",sans-serif;
color:black'>&nbsp;</span></p>

<p class=MsoNormal style='margin-bottom:0cm;line-height:normal;text-autospace:
none'><b><span style='font-size:12.0pt;font-family:Calibri-Bold;color:red'>Cinematic,
Semi Classical &amp; Folk dance (Below 8 years &amp; 8 to 10 years)</span></b></p>

<p class=MsoListParagraphCxSpFirst style='margin-bottom:0cm;text-indent:-18.0pt;
line-height:normal;text-autospace:none'><span style='font-size:10.5pt;
font-family:Symbol'>Þ<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><span style='font-size:10.5pt;color:black'>Maximum allowed time
is 4 min.</span></p>

<p class=MsoListParagraphCxSpMiddle style='margin-bottom:0cm;text-indent:-18.0pt;
line-height:normal;text-autospace:none'><span style='font-size:10.5pt;
font-family:Symbol'>Þ<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><span style='font-size:10.5pt;color:black'>Film songs in any
language is allowed.</span></p>

<p class=MsoListParagraphCxSpLast style='margin-bottom:0cm;text-indent:-18.0pt;
line-height:normal;text-autospace:none'><span style='font-size:8.0pt;
font-family:Symbol'>Þ<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span><span style='font-size:10.5pt;color:black'>Video to be recorded
Indoor/Outdoor considering COVID Protocols.</span><s><span style='color:black'><br>
<br>
</span></s></p>

<p class=MsoNormal style='margin-bottom:0cm;line-height:normal;text-autospace:
none'><b><span style='font-size:12.0pt;font-family:Calibri-Bold;color:red'>Cinematic,
Semi Classical &amp; Folk dance (11 to 14 years)</span></b></p>

<p class=MsoListParagraphCxSpFirst style='margin-bottom:0cm;text-indent:-18.0pt;
line-height:normal;text-autospace:none'><span style='font-family:Symbol'>Þ<span
style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp; </span></span><span
style='color:black'>Maximum allowed time is 5 min.</span></p>

<p class=MsoListParagraphCxSpMiddle style='margin-bottom:0cm;text-indent:-18.0pt;
line-height:normal;text-autospace:none'><span style='font-family:Symbol'>Þ<span
style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp; </span></span><span
style='color:black'>Film songs in any language is allowed.</span></p>

<p class=MsoListParagraphCxSpLast style='margin-bottom:0cm;text-indent:-18.0pt;
line-height:normal;text-autospace:none'><span style='font-family:Symbol'>Þ<span
style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp; </span></span><span
style='color:black'>Video to be recorded Indoor/Outdoor considering COVID
Protocols.<br>
<br>
</span></p>

<p class=MsoNormal style='margin-bottom:0cm;line-height:normal;text-autospace:
none'><b><span style='font-size:12.0pt;font-family:Calibri-Bold;color:red'>Group
Dance (8 Years &amp; Below, 12 years&amp; Below 15years)</span></b></p>

<p class=MsoListParagraphCxSpFirst style='margin-bottom:0cm;text-indent:-18.0pt;
line-height:normal;text-autospace:none'><span style='font-family:Symbol'>Þ<span
style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp; </span></span><span
style='color:black'>Maximum allowed time is 5 min.</span></p>

<p class=MsoListParagraphCxSpMiddle style='margin-bottom:0cm;text-indent:-18.0pt;
line-height:normal;text-autospace:none'><span style='font-family:Symbol'>Þ<span
style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp; </span></span><span
style='color:black'>Film/Folk songs in any language is allowed.</span></p>

<p class=MsoListParagraphCxSpMiddle style='margin-bottom:0cm;text-indent:-18.0pt;
line-height:normal;text-autospace:none'><span style='font-family:Symbol'>Þ<span
style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp; </span></span><span
style='color:black'>CD/Music is allowed, Music instruments cannot be played.</span></p>

<p class=MsoListParagraphCxSpMiddle style='margin-bottom:0cm;text-indent:-18.0pt;
line-height:normal;text-autospace:none'><span style='font-family:Symbol'>Þ<span
style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp; </span></span><span style='color:black'>Maximum Number of participants should be 8, considering COVID Protocol.</span></p>

<p class=MsoListParagraphCxSpLast style='margin-bottom:0cm;text-indent:-18.0pt;
line-height:normal;text-autospace:none'><span style='font-family:Symbol'>Þ<span
style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp; </span></span><span
style='color:black'>Participants should arrange Make-up and Costumes.</span></p>

<p class=MsoNormal style='margin-bottom:0cm;line-height:normal;text-autospace:
none'><span style='font-size:6.0pt;font-family:"ArialNarrow",sans-serif;
color:black'>&nbsp;</span></p>

<p class=MsoNormal><span style='color:black'>For enquiries, please write us to </span><a
href="mailto:icachildrenfest2021@gmail.com">icachildrenfest2021@gmail.com</a> </p>

<p class=MsoNormal><b><i><span style='font-size:14.0pt;line-height:106%;
color:red'>*****INDIAN CULTURAL ASSOCIATION Organisers reserve the right to
change any of these Rules and Regulations at any time without notice*****</span></i></b></p>

<!---< <p class=MsoNormal><a href="Rules&amp;Regulations.pdf"><b><span
style='font-size:20.0pt;line-height:106%;font-family:"&amp;quot",serif;
color:#0563C1'>Download Rules &amp; Regulations</span></b></a><span
style='font-size:8.0pt;line-height:106%;font-family:"&amp;quot",serif;
color:black'><o:p></o:p></span></p>

<p class=MsoNormal><span style='font-size:10.0pt;line-height:106%;font-family:
"&amp;quot",serif;color:black'>(Please note Rules &amp; Regulations may
update/change without any notice)</span><span style='font-family:"&amp;quot",serif;
color:black'><o:p></o:p></span></p> >----->


</div>



</body>

</html>

                
                
                
                
                
                
                
                
                
                
                
		</div>
	</div>
	<div class="clear"></div>
		<!---start-footer----->
		<?php include "includes/footer.php"; ?>
		<!---End-footer----->
		<!---End-wrap---->
		
	</body>
</html>

